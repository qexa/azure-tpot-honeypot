# Changelog

All notable changes to this project will be documented in this file.

## [1.0.0] - 2025-09-03
- Initial release of **Azure T-Pot Honeypot** with scripts, ARM template, Terraform IaC, docs, and CI workflow.
