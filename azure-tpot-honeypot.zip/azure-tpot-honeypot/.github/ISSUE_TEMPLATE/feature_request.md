---
name: Feature request
about: Suggest an idea
title: "[FEATURE] "
labels: enhancement
---

**Problem**
What are you trying to solve?

**Proposal**
Describe the desired solution.

**Alternatives**
Other approaches considered.

**Additional context**
